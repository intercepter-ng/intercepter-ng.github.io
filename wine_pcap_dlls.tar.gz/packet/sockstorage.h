#include "bittypes.h"
/*
struct sockaddr_storage {
#ifdef HAVE_SOCKADDR_SA_LEN
        u_int8_t __ss_len;
        u_int8_t __ss_family;
        u_int8_t fill[126];
#else
        u_int8_t __ss_family;
        u_int8_t fill[127];
#endif //};
*/
