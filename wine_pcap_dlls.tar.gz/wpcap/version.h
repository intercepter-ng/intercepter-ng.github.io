//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
//

// 3.1.0.24   -->  WinPcap  3.1 beta4
// 3.1.0.27   -->  WinPcap  3.1 RTM
// 3.2.0.29	  -->  WinPcap  3.2 alpha1
// 4.0.0.374  -->  WinPcap  4.0 alpha1
// 4.0.0.592  -->  WinPcap  4.0 beta1
// 4.0.0.655  -->  WinPcap  4.0 beta2
// 4.0.0.703  -->  WinPcap  4.0 beta3
// 4.0.0.755  -->  WinPcap  4.0 RTM
// 4.1.0.902  -->  WinPcap  4.1 beta
// 4.1.0.1048 -->  WinPcap  4.1 beta2
// 4.1.0.1124 -->  WinPcap  4.1 beta3
// 4.1.0.1237 -->  WinPcap  4.1 beta4
// 4.1.0.1452 -->  WinPcap  4.1 beta5
// 4.1.0.1752 -->  WinPcap  4.1 RTM
// 4.1.0.1753 -->  WinPcap  4.1.1 RTM
// 4.1.0.2001 -->  WinPcap  4.1.2 RTM

#define WINPCAP_MAJOR	4
#define WINPCAP_MINOR	1
#define WINPCAP_REV		0
#define WINPCAP_BUILD	2001
#define WINPCAP_VER_STRING	"4.1.0.2001"
#define WINPCAP_PACKET9x_STRING_VERSION	"4.1.2"
#define WINPCAP_WPCAP_STRING_VERSION "4.1.2"

#define WINPCAP_COMPANY_NAME 			"CACE Technologies, Inc."

#define WINPCAP_PRODUCT_NAME 			"WinPcap"

#define WINPCAP_COPYRIGHT_STRING 		"Copyright � 2005-2010 CACE Technologies. Copyright � 1999-2005 NetGroup, Politecnico di Torino."
#define WINPCAP_WANPACKET_COPYRIGHT_STRING "Copyright � 2005-2010 CACE Technologies. Copyright � 2003-2005 NetGroup, Politecnico di Torino."
#define WINPCAP_INSTALLERHELPER_COPYRIGHT_STRING "Copyright � 2007-2010 CACE Technologies."
#define WINPCAP_RPCAPD_COPYRIGHT_STRING "Copyright � 2005-2010 CACE Technologies. Copyright � 2003-2005 NetGroup, Politecnico di Torino."

#define WINPCAP_BUILD_DESCRIPTION 		""
#define WINPCAP_PRIVATE_BUILD			""
#define WINPCAP_LIBPCAP_VERSION			"1.0rel0b branch (20091008)"
